import React from 'react'

const ProcessedImage = () => {
    return (
        <>
            <h1>This is manage Processed Image Sites component</h1>
        </>
    )
}

export default ProcessedImage;