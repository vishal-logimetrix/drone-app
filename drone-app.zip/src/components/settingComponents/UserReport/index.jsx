import React from 'react'

const UserReport = () => {
    return (
        <>
            <h1>This is User Report component</h1>
        </>
    )
}

export default UserReport;