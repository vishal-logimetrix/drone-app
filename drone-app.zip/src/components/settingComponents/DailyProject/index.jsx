import React from 'react'

const DailyProject = () => {
    return (
        <>
            <h1>This is Daily Project sites component</h1>
        </>
    )
}

export default DailyProject;