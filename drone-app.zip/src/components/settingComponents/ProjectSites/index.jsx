import React from 'react'

const ProjectSites = () => {
    return (
        <>
            <h1>This is Project Sites Component</h1>
        </>
    )
}

export default ProjectSites;