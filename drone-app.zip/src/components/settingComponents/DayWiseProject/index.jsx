import React from 'react'

const DayWiseProject = () => {
    return (
        <>
            <h1>This is Day Wise Project Sites component</h1>
        </>
    )
}

export default DayWiseProject;