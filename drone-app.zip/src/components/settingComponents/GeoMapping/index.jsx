import React from 'react'

const GeoMapping = () => {
    return (
        <>
            <h1>This is Geo Mapping component</h1>
        </>
    )
}

export default GeoMapping;