import React from 'react'

const Permissions = () => {
  return (
    <>
      
    </>
  )
}

export default Permissions
